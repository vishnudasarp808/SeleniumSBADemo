package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import page.HomePage;

public class SampleTest {
	
	static WebDriver driver;

	static String browser ="chrome";  // Toggle between browsers
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		if(browser.equals("chrome")) {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium Softwares\\chromedriver_win32\\chromedriver.exe");	
		driver=new ChromeDriver();
		}
		else if(browser.equals("firefox")){
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium Softwares\\chromedriver_win32\\chromedriver.exe");	
		driver=new ChromeDriver();	
		}
		else if(browser.equals("IE")){
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium Softwares\\chromedriver_win32\\chromedriver.exe");	
		driver=new ChromeDriver();
		}
		
		HomePage home=new HomePage(driver);	
		home.method1();
			
	}

	
	
}

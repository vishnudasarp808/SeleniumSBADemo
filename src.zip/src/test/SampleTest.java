package test;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;



import page.HomePage;

public class SampleTest {
	static WebDriver driver; //Declare driver outside main method
	
	//static String browser="firefox"; //Configure browser
	static String browser;
	
	public static void main(String args[]) throws IOException{
		
		File file = new File("D:\\SeleniumKBA\\Demo3\\SBA_Demo\\src\\config.properties");
		FileInputStream fileInput = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(fileInput);
		browser=prop.getProperty("browser");
		
		System.out.println("browser=" +browser);
		
		//Set Browser
		
		if(browser.equals("chrome")){
			System.out.println("into Chrome");
			System.setProperty("webdriver.chrome.driver", "D:\\Selenium Softwares\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		
		else if(browser.equals("firefox")){
			
			File pathBinary = new File("C:\\Users\\285012\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
			FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
			FirefoxProfile firefoxProfile = new FirefoxProfile();       
			driver = new FirefoxDriver(firefoxBinary, firefoxProfile);
			
			//driver=new FirefoxDriver();
		}
		else if(browser.equals("internetExplorer")){
			System.setProperty("webdriver.ie.driver", "pathToTheIEDriver");
			WebDriver driver = new InternetExplorerDriver();

		}
		
		HomePage home=new HomePage(driver);
		home.login();
		driver.manage().window().maximize();
		home.validateTitle();
		home.enterDates();
		takeScreenshot();
		driver.quit();
	}
	
	// Take Screenshot
	public static void takeScreenshot(){

		// Take screenshot and store as a file format
		
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			// now copy the  screenshot to desired location using copyFile method

			FileUtils.copyFile(src, new File("D:\\SeleniumKBA\\Demo3\\SBA_Demo\\src\\Results\\"+System.currentTimeMillis()+".png"));
		}

		catch (IOException e)

		{

			System.out.println(e.getMessage());

		}

	}


}

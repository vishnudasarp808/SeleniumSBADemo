package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class getdriver {
	  /*WebDriver driver;
	
	public webdriver(String browser){
	 
		this.driver=getdriver(browser);
	}
	*/
	static WebDriver driver;
	
	/*public webdriver(String browser){
		this.driver = getdriver(browser);
	}*/
	
	public WebDriver getdriver(String browser){
		//WebDriver driver = null;
		switch(browser){    
		case "Chrome":
			driver = new ChromeDriver();
			break;
			
		case "FireFox":
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.download.folderList", 2);
			profile.setPreference("browser.download.dir", "");
			profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/zip");
			profile.setPreference("plugin.state.java", 2);
			driver = new FirefoxDriver(profile);
			break;

		case "InternetExplorer":
			DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
			cap.setCapability("nativeEvents", false); 
			cap.setCapability("ignoreZoomSetting", true);
			cap.setCapability("unexpectedAlertBehaviour", "accept");
			cap.setCapability("ignoreProtectedModeSettings", true);
			//cap.setCapability("disable-popup-blocking", true);
			cap.setCapability("enablePersistentHover", true);
			//cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			System.setProperty("webdriver.ie.driver", "InternetExplorerDriverPath");
			driver = new InternetExplorerDriver(cap);
			break;

		}
		return driver;
	}	

	public void test(){
		
	}
}

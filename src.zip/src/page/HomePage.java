package page;

import java.io.File;
import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.WebDriver;

import objects.HomePageElements;

public class HomePage {
	WebDriver driver;
	
	public HomePage(WebDriver driver){
		this.driver = driver;
	}
	
	public void login(){
		driver.get("http://toolsqa.com/automation-practice-form/");
	}
	
	public void validateTitle(){
		
	String title=driver.findElement(HomePageElements.txtHomePageTitle).getText();
	if(title.equals("Practice Automation Form"))
		System.out.println("Title is valid");
	else
		System.out.println("Title is not Valid");
	}
	
	public void enterDates() throws IOException{
		
		driver.findElement(HomePageElements.txtDate).sendKeys(getDate());
		
	}

	public String getDate() throws IOException{
		FileInputStream inputFile = new FileInputStream(new File("D:\\SeleniumKBA\\Demo3\\SBA_Demo\\src\\data\\dataSheet.xls"));
   		HSSFWorkbook inputWorkbook = new HSSFWorkbook (inputFile);
		HSSFSheet inputSheet = inputWorkbook.getSheetAt(0);
		HSSFCell cell = inputSheet.getRow(1).getCell(0);
		String date =String.valueOf(cell);
		System.out.println(date);
		return date;
				
	}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Common Methods
		
	public void writeExcel() throws IOException{
	HSSFWorkbook outputWorkBook=openExcel("outPutFilePath");
		HSSFSheet outputSheet =  getSheet(outputWorkBook);
		HSSFRow row1 = outputSheet.createRow(getNextRow(outputSheet));
		HSSFCell  TestCaseName= row1.createCell(0);
		TestCaseName.setCellValue("Value");
		HSSFCell Status = row1.createCell(1);
		Status.setCellValue("FAIL");
		closeExcel(outputWorkBook,"outPutFilePath");
	}
	
	public void readExcel() throws IOException{
		FileInputStream inputFile = new FileInputStream(new File("D:\\SeleniumKBA\\Demo3\\SBA_Demo\\src\\data\\dataSheet.xlsx"));
		//FileInputStream inputFile = new FileInputStream(new File(""));
   		HSSFWorkbook inputWorkbook = new HSSFWorkbook (inputFile);
		HSSFSheet inputSheet = inputWorkbook.getSheetAt(0);
			for(int i=0; i<inputSheet.getLastRowNum(); i++){
				HSSFCell cell = inputSheet.getRow(i).getCell(0);
				String link =String.valueOf(cell);
				driver.get(link);
			 String title=driver.getTitle();
			 System.out.println("Title "+i+"=" +title);
			}
	}
	
	
	public static  HSSFSheet getSheet(HSSFWorkbook workbook) throws IOException{
		HSSFSheet sheet = workbook.getSheetAt(0);
		return sheet;
	}

	public static  int getNextRow(HSSFSheet sheet) throws IOException{
		int rows=sheet.getLastRowNum();
		int rowadd = rows+1;
		System.out.println(rowadd);
		int nextRow = rowadd;
		return nextRow;
	}
	
	public static void closeExcel(HSSFWorkbook workbook,String file) throws IOException{
		FileInputStream outputExcelfile = new FileInputStream(new File(file));
		outputExcelfile.close();
		try (FileOutputStream outputStream = new FileOutputStream(file)) {
	        workbook.write(outputStream);
	        System.out.println("Excel written successfully..");

	}
	}
	
	public static HSSFWorkbook openExcel(String file) throws IOException{
		FileInputStream outputExcelfile = new FileInputStream(new File(file));
		HSSFWorkbook workbook = new HSSFWorkbook (outputExcelfile);
		return workbook;
	}

	
}
	
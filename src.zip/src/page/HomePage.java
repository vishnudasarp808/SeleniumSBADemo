package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import elements.HomePageElements;

public class HomePage {

	WebDriver driver;
	//public static By element1=By.xpath("");
		
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void method1(){
		System.out.println("Test");
		driver.findElement(HomePageElements.element1).click();
	}
}

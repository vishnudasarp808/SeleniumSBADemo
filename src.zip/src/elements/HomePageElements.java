package elements;

import org.openqa.selenium.By;

public class HomePageElements {
	
	public static By element1=By.xpath("");
	
	

}

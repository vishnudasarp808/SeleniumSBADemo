package objects;

import org.openqa.selenium.By;

public class HomePageElements {

	public static By txtHomePageTitle=By.xpath("//div[@id='content']/h1");
	public static By txtDate=By.xpath("//input[@id='datepicker']");
	
}

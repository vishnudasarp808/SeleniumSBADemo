package TestNG;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import page.HomePage;

public class Test {
	static WebDriver driver;
	@BeforeTest
	public void setup(){
		File pathBinary = new File("C:\\Users\\285012\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
		FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
		FirefoxProfile firefoxProfile = new FirefoxProfile();       
		driver = new FirefoxDriver(firefoxBinary, firefoxProfile);
	}
	
	@org.testng.annotations.Test
	public void testing() throws IOException{
		HomePage home=new HomePage(driver);
		home.login();
		driver.manage().window().maximize();
		home.validateTitle();
		home.enterDates();
		//takeScreenshot();
		driver.quit();
	}
	
	@org.testng.annotations.Test
	public void testing1() throws IOException{
		HomePage home=new HomePage(driver);
		home.login();
		driver.manage().window().maximize();
		home.validateTitle();
		home.enterDates();
		//takeScreenshot();
		driver.quit();
	}
	
	@AfterTest
	public void quit(){
		
	}

}
